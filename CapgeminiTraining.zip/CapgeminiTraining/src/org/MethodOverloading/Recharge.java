package org.MethodOverloading;

public class Recharge {

	public void pay(String username,String password )
	{
		System.out.println("Enter Username And Paswword for Paying Money");
	}
	
	public void pay(long debitno,String expirydate )
	{
		System.out.println("Enter debitno And expirydate for Paying Money");
	}
	
	public void pay(int upi,String password )
	{
		System.out.println("Enter upi And Paswword for Paying Money");
	}

}
