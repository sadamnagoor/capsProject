package org.BufferedReader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class BufferReader 
{
public static void main(String[] args) {
	String path="E:/webTechnologies/Demo/file.txt";
	
	File f1=new File(path);
	FileReader fr=null;
	BufferedReader br=null;
	try {
		 fr = new FileReader(f1);
		 br=new BufferedReader(fr);
		 String r=br.readLine();
		 while(r!=null)
		 {
			 System.out.println(r);
			r=br.readLine();
		 }
		
	} catch ( IOException e) {
		e.printStackTrace();
	}
	finally {
		try {
			fr.close();
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
}
}
