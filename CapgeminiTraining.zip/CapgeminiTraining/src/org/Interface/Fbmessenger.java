package org.Interface;

public class Fbmessenger extends WhatsApp {

	@Override
	public void text() {

		System.out.println("Text using Fb messenger");
	}

}
