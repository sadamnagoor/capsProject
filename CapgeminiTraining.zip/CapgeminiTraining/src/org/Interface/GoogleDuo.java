package org.Interface;

public abstract class GoogleDuo implements Application{

	@Override
	public void videoCall() {

		System.out.println("Use google duo for video calling");
	}

	
}
