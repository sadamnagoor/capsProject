package org.Interface;

public abstract class WhatsApp extends GoogleDuo{

	@Override
	public void call() {
		System.out.println("Call Using Whats App Application ");
		
	}

}
