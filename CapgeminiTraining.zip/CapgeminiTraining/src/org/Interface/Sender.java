package org.Interface;

public class Sender {

	public void send(Application app)
	{
      app.videoCall();
      app.call();
      app.text();


	}
}
class Main
{
	public static void main(String[] args) {
		Sender s=new Sender();
		s.send(new Fbmessenger());
	}
}
