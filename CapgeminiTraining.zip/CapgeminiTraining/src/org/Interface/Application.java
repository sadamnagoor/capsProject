package org.Interface;

public interface Application {

	public void videoCall();
	public void call();
	public void text();
}
