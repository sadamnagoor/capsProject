package org.Deserialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import org.Serialization.Student;

public class Deserialization
{
	public static void main(String[] args) {
		
		String path="E:/webTechnologies/Demo/file1.ser";
		File f1=new File(path);
		FileInputStream fin=null;
		ObjectInputStream obj=null;
		try
		{
			fin=new FileInputStream(f1);
			obj=new ObjectInputStream(fin);
			Object ob=obj.readObject();
			if(ob instanceof Student)
			{
				Student stu=(Student)ob;
				System.out.println("Student name is: "+stu.name);
				System.out.println("Student id is: "+stu.id);
			}
			else
			{
				System.out.println(ob);
			}
		}
			catch(Exception e)
			{
				System.out.println("Handled");
			}
			finally {
				try {
					fin.close();
					obj.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				;
			}
		}
	}

