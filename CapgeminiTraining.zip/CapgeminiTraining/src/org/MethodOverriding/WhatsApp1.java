package org.MethodOverriding;

public class WhatsApp1 extends WhatsApp{

	public void msg()
	{
		System.out.println("Msg Along With That Notificagtions");
	}
}
