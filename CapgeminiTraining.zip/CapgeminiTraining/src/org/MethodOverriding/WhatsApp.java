package org.MethodOverriding;

public class WhatsApp {
	
	public void msg()
	{
		System.out.println("Msg in Whats app");
	}

}
