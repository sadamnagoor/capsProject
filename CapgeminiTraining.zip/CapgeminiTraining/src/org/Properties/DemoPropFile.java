package org.Properties;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class DemoPropFile
{
public static void main(String[] args) {
	String path="E:/webTechnologies/Demo/file2.properties";
	File f1=new File(path);
	
	FileReader fr=null;
	Properties pro=null;
    try
	{
    	fr=new FileReader(f1);
    	pro=new Properties();
    	pro.load(fr);
    	String s1=pro.getProperty("userName");
    	System.out.println("Username is: "+s1);
    	String s2=pro.getProperty("passWord");
    	System.out.println("password is: "+s2);
	}
    catch(Exception e)
    {
    	System.out.println("Handled");
    }
    finally {
		try {
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
}
