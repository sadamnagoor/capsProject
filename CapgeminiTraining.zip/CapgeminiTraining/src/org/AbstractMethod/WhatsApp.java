package org.AbstractMethod;

public class WhatsApp extends Messaing{

	@Override
	public void msg() {
   System.out.println("message using whatsapp");		
   
	}
	public void call()
	{
		System.out.println("Calls Also Done");
	}
}
class Main
{
	public static void main(String[] args) {
		Messaing ms=new WhatsApp();
		ms.msg();
       	WhatsApp wts=(WhatsApp)ms;
       	wts.call();
	}
}

