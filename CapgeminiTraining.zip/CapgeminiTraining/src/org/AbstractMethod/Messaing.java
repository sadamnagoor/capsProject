package org.AbstractMethod;

public abstract class Messaing {
	
	public abstract void msg();
}
