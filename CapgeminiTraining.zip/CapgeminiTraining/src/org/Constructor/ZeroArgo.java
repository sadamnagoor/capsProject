package org.Constructor;

public class ZeroArgo {

	ZeroArgo()
	{
		this(10,20,30);
		
		System.out.println("0-arg");
	}
	ZeroArgo(int a)
	{
		this();
		System.out.println("1-arg");
	}
	ZeroArgo(int b,int c)
	{
		this(25);
		System.out.println("2-arg");
	}
	ZeroArgo(int a,int b,int c)
	{
		System.out.println("3-arg");
	}
}
class Main{
	public static void main(String[] args) {
		ZeroArgo ref=new ZeroArgo(23,67);
	}
}

