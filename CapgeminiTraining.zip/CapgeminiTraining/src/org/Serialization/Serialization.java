package org.Serialization;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serialization 
{
public static void main(String[] args) {
	
	Student stu=new Student(1, "rahul");
	
	String path="E:/webTechnologies/Demo/file1.ser";
	
	File f1=new File(path);
	
	FileOutputStream fout=null;
	ObjectOutputStream obj=null;
	
	try {
		f1.createNewFile();
		 fout=new FileOutputStream(f1);
		 obj=new ObjectOutputStream(fout);
		 obj.writeObject(stu);
		 System.out.println("Object Written");
		 
	} catch ( IOException e) {
		System.out.println("Exception Handled");
	}
	finally
	{
		try {
			fout.close();
			obj.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
}
