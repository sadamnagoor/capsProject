package org.Collection.LinkedList;

import java.util.LinkedList;
import java.util.ListIterator;

import org.Collection.ArrayList.Camera;
public class Demo1LinkedList
{
public static void main(String[] args) {
	Camera ca1=new Camera(20, "Sony", 15000);
	Camera ca2=new Camera(10, "Lg", 20000);
	Camera ca3=new Camera(5, "camel", 35000);
	Camera ca4=new Camera(8, "lsdm", 45000);
	Camera ca5=new Camera(7, "nd", 55000);
	Camera ca6=new Camera(3, "Sony", 15000);
 
	LinkedList ll=new LinkedList();
	
	ll.add(ca4);
	ll.add(ca6);
	ll.add(ca5);
	ll.add(ca2);
	ll.add(ca1);
	ll.add(ca3);
	
	ListIterator it=ll.listIterator();
	
	while(it.hasNext())
	{
		Object obj=it.next();
		System.out.println(obj);
	}
}
}
