package org.Collection.TreeSet;

import java.util.TreeSet;

public class Demo1TreeSet 
{
	public static void main(String[] args) {
		Mobile mo1=new Mobile(1, "samsung", 9999);
		Mobile mo2=new Mobile(2, "samsung", 9999);
		Mobile mo3=new Mobile(3, "samsung", 9999);
		Mobile mo4=new Mobile(4, "samsung", 9999);
		Mobile mo5=new Mobile(5, "samsung", 9999);
		Mobile mo6=new Mobile(6, "samsung", 9999);
		Mobile mo7=new Mobile(7, "samsung", 9999);
		Mobile mo8=new Mobile(8, "samsung", 9999);
		Mobile mo9=new Mobile(9, "samsung", 9999);
		Mobile mo10=new Mobile(10, "samsung", 9999);
		TreeSet<Mobile> tree=new TreeSet<Mobile>();
		tree.add(mo9);
		tree.add(mo8);
		tree.add(mo7);
		tree.add(mo6);
		tree.add(mo10);
		tree.add(mo5);
		tree.add(mo4);
		tree.add(mo1);
		tree.add(mo2);
		tree.add(mo3);
		for (Mobile mobile : tree) {
			System.out.println(mobile);
		}
		
	}
}

