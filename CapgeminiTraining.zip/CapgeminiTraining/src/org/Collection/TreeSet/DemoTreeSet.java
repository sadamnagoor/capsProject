package org.Collection.TreeSet;

import java.util.TreeSet;

import org.Collection.ArrayList.Employee;

public class DemoTreeSet
{
public static void main(String[] args) {

	Employee emp1=new Employee(1, "nagoor", 10000);
	Employee emp2=new Employee(2, "sai", 10000);
	Employee emp3=new Employee(3, "vamsi", 10000);
	Employee emp4=new Employee(4, "karthik", 10000);
	Employee emp5=new Employee(5, "dhoni", 10000);
	Employee emp6=new Employee(6, "virat", 10000);
	Employee emp7=new Employee(7, "pant", 10000);
	Employee emp8=new Employee(8, "hardik", 10000);
	Employee emp9=new Employee(9, "krunal", 10000);
	Employee emp10=new Employee(9, "krunal", 10000);
	
	TreeSet hs=new TreeSet();
	hs.add(emp1);
	hs.add(emp2);
	hs.add(emp3);
	hs.add(emp4);
	hs.add(emp5);
	hs.add(emp6);
	hs.add(emp7);
	hs.add(emp8);
	hs.add(emp9);
	hs.add(emp10);
	
	for (Object object : hs) {
		System.out.println(object);
	}
}
}
