package org.Collection.TreeSet;

public class Mobile implements Comparable {

	public int id;
	public String modal;
	public double price;
	
	public Mobile(int id,String modal,double price)
	{
		this.id=id;
		this.modal=modal;
		this.price=price;
	}
	
	
	@Override
	public String toString() {
		return "Mobile [id=" + id + ", modal=" + modal + ", price=" + price + "]";
	}
	@Override
	public int compareTo(Object obj) {
		Mobile m=(Mobile)obj;
		return this.id-m.id;
	}

}
