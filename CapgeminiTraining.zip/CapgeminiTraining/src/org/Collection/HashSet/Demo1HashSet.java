package org.Collection.HashSet;

import java.util.HashSet;

public class Demo1HashSet {
public static void main(String[] args) {
	Laptop la1=new Laptop(1, 30000, "Dell");
	Laptop la2=new Laptop(5, 30000, "Lenovo");
	Laptop la3=new Laptop(8, 30000, "Apple");
	Laptop la4=new Laptop(7, 30000, "Sony");
	Laptop la5=new Laptop(9, 30000, "Dell");
	Laptop la6=new Laptop(4, 30000, "Dell");
	Laptop la7=new Laptop(3, 30000, "Dell");
	Laptop la8=new Laptop(2, 30000, "Dell");
	Laptop la9=new Laptop(6, 30000, "Dell");
	Laptop la10=new Laptop(1,30000,"Dell");
	
	HashSet<Laptop> hs=new HashSet<Laptop>();
	hs.add(la7);
	hs.add(la6);
	hs.add(la8);
	hs.add(la2);
	hs.add(la3);
	hs.add(la1);
	hs.add(la4);
	hs.add(la9);
	hs.add(la5);
	hs.add(la10);
	
	for(Object obj:hs)
	{
		System.out.println(obj);
	}
}
}
