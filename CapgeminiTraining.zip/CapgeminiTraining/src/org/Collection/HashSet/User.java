package org.Collection.HashSet;

public class User {

	int id;
	String email;
	String name;
	String password;
	
	
		
	public User(int id, String email, String name, String password) {

		System.out.println("Paramerised constructor");	
		this.id = id;
		this.email = email;
		this.name = name;
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", email=" + email + ", name=" + name + ", password=" + password + "]";
	}

	@Override
	public int hashCode() {
		
		System.out.println("Calling Hashcode");
		return this.id;
	}

	@Override
	public boolean equals(Object obj) {
		
		System.out.println("Calling equals method");
		
		User user=(User)obj;
		return this.id==user.id;
	}
	
	
	
}
