package org.Collection.HashSet;

import java.util.HashSet;

public class Main {

	public static void main(String[] args) {
		
		
		
		User user1=new User(1, "abc@gmail.com", "abc", "aabbcc");
		User user2=new User(2, "def@gmail.com", "def", "ddeeff");
		User user3=new User(3, "ghi@gmail.com", "ghi", "gghhii");
		User user4=new User(4, "jkl@gmail.com", "jkl", "jjkkll");
		User user5=new User(5, "mno@gmail.com", "mno", "mmnnoo");
		User user6=new User(6, "pqr@gmail.com", "pqr", "ppqqrr");
		User user7=new User(1, "abc@gmail.com", "abc", "secret");
		
		HashSet<User> set=new HashSet<User>();
		set.add(user1);
		set.add(user2);
		set.add(user3);
		set.add(user3);
		set.add(user4);
		set.add(user5);
		set.add(user6);
		set.add(user7);
		
		for (User obj : set) {
			System.out.println(obj);
		}
		}
}
