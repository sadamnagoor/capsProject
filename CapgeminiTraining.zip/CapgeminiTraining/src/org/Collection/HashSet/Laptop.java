package org.Collection.HashSet;

public class Laptop 
{
	int id;
	double price;
	String modal;
public Laptop(int id,double price,String modal)

{
	this.id=id;
	this.price=price;
	this.modal=modal;
}
@Override
public String toString() {
	return "id="+id +","+"price="+price+","+"modal="+modal;
}
@Override
public int hashCode()
{
	System.out.println("Calling HashCode Method");
	return this.id;
	
}
@Override
public boolean equals(Object obj)
{
	System.out.println("Calling equals Method");
	Laptop la=(Laptop)obj;
	return this.id==la.id;
}
}
