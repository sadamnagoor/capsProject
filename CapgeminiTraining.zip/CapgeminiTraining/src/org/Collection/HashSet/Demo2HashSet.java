package org.Collection.HashSet;

import java.util.HashSet;

import org.Collection.ArrayList.Camera;

public class Demo2HashSet 
{
public static void main(String[] args) {
	Camera ca1=new Camera(20, "Sony", 15000);
	Camera ca2=new Camera(10, "Lg", 20000);
	Camera ca3=new Camera(5, "camel", 35000);
	Camera ca4=new Camera(8, "lsdm", 45000);
	Camera ca5=new Camera(7, "nd", 55000);
	Camera ca6=new Camera(3, "Sony", 15000);
	
	HashSet hs=new HashSet();
		/*
		 * hs.add(ca1); hs.add(ca2); hs.add(ca3); hs.add(ca4); hs.add(ca5); hs.add(ca6);
		 */
	  
		/*
		 * hs.add("Sony"); hs.add("Lg"); hs.add("camel"); hs.add("lsdm"); hs.add("nd");
		 * hs.add("Sony");
		 */
		/*
		 * hs.add(2); hs.add(3); hs.add(1); hs.add(4); hs.add(5); hs.add(6); hs.add(7);
		 */
	 hs.add("ea");
     hs.add("fb");
     hs.add("gc");
	 hs.add("az");
	 hs.add("bg");
	 hs.add("cf");
	 hs.add("df");
	    
	
	for (Object object : hs) {
		System.out.println(object);
	}
	
	
	
}
}
