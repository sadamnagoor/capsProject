package org.Collection.ArrayList;

public class Camera
{

	public int lens;
	public String modal;
	public double price;
	
	public Camera(int lens, String modal, double price) {
		this.lens = lens;
		this.modal = modal;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Camera [lens=" + lens + ", modal=" + modal + ", price=" + price + "]";
	}
	
	
	
	
	
	
}
