package org.Collection.ArrayList;

public class Employee implements Comparable
{

	public int id;
	public String name;
    public double salary;
	
    public Employee(int id,String name,double salary)
    {
    	this.id=id;
    	this.name=name;
    	this.salary=salary;
    	
    }

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
	// overriding hashcode for comare the duplicate content present in object 
	
	/*
	 * @Override public int hashCode() {
	 * System.out.println("Hashcode method is Calling"); return this.id; }
	 */
	
	// overriding equals for comare the duplicate content present in object 
	
	
	/*
	 * @Override public boolean equals(Object obj) {
	 * System.out.println("Calling Equals equals Method"); Employee
	 * emp=(Employee)obj; return this.id==emp.id; }
	 */

	// overriding compareto for sorting based on id
	
	/*
	 * @Override public int compareTo(Object obj) { Employee emp=(Employee)obj;
	 * return this.id-emp.id; }
	 */
	
	// overriding compareto for sorting based on name
	
	/*
	 * @Override public int compareTo(Object obj) { Employee emp=(Employee)obj;
	 * return this.name.compareTo(emp.name); }
	 */
    
	// overriding compareto for sorting based on salary
	
	@Override
	public int compareTo(Object obj) 
	{ 
		Employee emp=(Employee)obj;
	 return ((int)(this.salary=emp.salary)*1000);
	 }
	
}
