package org.Collection.ArrayList;

public class Mobile 
{
     public String modal;
     public double price;
     public String color;
      
	public Mobile(String modal, double price, String color) {
		this.modal = modal;
		this.price = price;
		this.color = color;
	}

	@Override
	public String toString() {
		return "Mobile [modal=" + modal + ", price=" + price + ", color=" + color + "]";
	}
      
	
      
}
