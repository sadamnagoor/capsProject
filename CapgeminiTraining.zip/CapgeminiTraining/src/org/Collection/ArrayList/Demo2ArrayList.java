package org.Collection.ArrayList;

import java.util.ArrayList;

public class Demo2ArrayList
{
public static void main(String[] args) {
	Camera ca1=new Camera(20, "Sony", 15000);
	Camera ca2=new Camera(10, "Lg", 20000);
	Camera ca3=new Camera(5, "camel", 35000);
	Camera ca4=new Camera(8, "lsdm", 45000);
	Camera ca5=new Camera(7, "nd", 55000);
	Camera ca6=new Camera(3, "Sony", 15000);
	
	
	ArrayList al=new ArrayList();
	al.add(ca5);
	al.add(ca4);
	al.add(ca6);
	al.add(ca2);
	al.add(ca3);
	al.add(ca1);
	al.add(null);
	al.add(null);
	al.add(ca5);
	
	ArrayList al1=new ArrayList(al);
	
	for(int i=0;i<al1.size();i++)
	{
	Object obj=al1.get(i);
    System.out.println(obj);
	}
}
}
