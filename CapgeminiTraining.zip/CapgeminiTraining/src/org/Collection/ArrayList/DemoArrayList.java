package org.Collection.ArrayList;

import java.util.ArrayList;

public class DemoArrayList {
public static void main(String[] args) {
	Employee emp1=new Employee(1, "nagoor", 10000);
	Employee emp2=new Employee(2, "sai", 10000);
	Employee emp3=new Employee(3, "vamsi", 10000);
	Student stu1=new Student(1, "john", 65.18);
	Student stu2=new Student(2,"curran",68.78);
	Student stu3=new Student(3,"sanju",70.25);
	Mobile mo1=new Mobile("samsung",9999,"black");
	Mobile mo2=new Mobile("moto",8999,"gold");
	Mobile mo3=new Mobile("vivo",15000,"white");
	
	ArrayList al=new ArrayList();
	
	al.add(emp1);
	al.add(emp2);
	al.add(emp3);
	al.add(stu1);
	al.add(stu2);
	al.add(stu3);
	al.add(mo1);
	al.add(mo2);
	al.add(mo3);

	for(int i=0;i<al.size();i++)
	{
		Object obj=al.get(i);
		if(obj instanceof Employee)
		{
			Employee emp=(Employee)obj;
			System.out.println("Employee id is: "+emp.id);
			System.out.println("Employee name is: "+emp.name);	
		}
		else if(obj instanceof Student)
		{
			Student stu=(Student)obj;
			System.out.println("Student id is: "+stu.id);
			System.out.println("Student name is: "+stu.name);
		}
		else if(obj instanceof Mobile)
		{
			Mobile mob=(Mobile)obj;
			System.out.println("Mobile modal is: "+mob.modal);
			System.out.println("Mobile color is: "+mob.color);
		}
		else
		{
			System.out.println(obj);
		}
	}
}
}
