package org.DesignPatterns.SingleTon;

public class DataBase 
{

	private static DataBase ref=null;
	
	private DataBase()
	{
		System.out.println("Object Created");
	}
	public static DataBase createDataBase()
	{
		if(ref==null)
		{
			ref=new DataBase();
			return ref;
		}
		else
		{
			return ref;
		}
	}
	public void storeData(String s)
	{
		System.out.println("Storing Data...."+s);
	}
	
}
