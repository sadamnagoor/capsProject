package org.DesignPatterns.SingleTon;

public class Data
{
public static void main(String[] args) {
	
	String data1="java";
	DataBase d1=DataBase.createDataBase();
	d1.storeData(data1);
	String data2="sql";
	DataBase d2=DataBase.createDataBase();
	d2.storeData(data2);
}	

}
