package org.FileWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Writing
{
public static void main(String[] args) {
	String data="java";
	String path="E:/webTechnologies/Demo/file.txt";
	
	File f1=new File(path);
	FileWriter fw=null;
	try {
		 fw=new FileWriter(path);
		fw.write(data);
		System.out.println("Succesfully Written");
	} catch (IOException e) {
		System.out.println("Handled Successfully");
	}
	finally {
		try {
			fw.flush();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
}
