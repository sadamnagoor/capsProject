package org.FileWriter;

import java.io.File;
import java.io.IOException;

public class FileCreating
{
	public static void main(String[] args) {
		
String path="E:/webTechnologies/Demo/file.txt";

File f1=new File(path);
 boolean res=false;
   try {
	res=f1.createNewFile();
} catch (IOException e) {
	System.out.println("Handled Succesfully");
	
}
   System.out.println("File Created: "+res);
	}

	}
