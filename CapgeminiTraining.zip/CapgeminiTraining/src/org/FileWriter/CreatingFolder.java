package org.FileWriter;

import java.io.File;

public class CreatingFolder 
{
	public static void main(String[] args) {
		
	
	String path="E:/webTechnologies/Demo";
	
	File f1=new File(path);
	boolean res=f1.mkdir();
	System.out.println("Folder is: "+res);
	
	}
	

}
