package org.FileWriter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReading
{
	public static void main(String[] args) {
		String path="E:/webTechnologies/Demo/file.txt";
		File f1=new File(path);
		FileReader fr=null;
		try {
			 fr=new FileReader(f1);
			 int i=fr.read();
			 while(i!=-1)
			 {
			System.out.print((char)i);
			i=fr.read();
			 }
			 System.out.println();
			System.out.println("FileReading is Succesfully");
		} catch (IOException e) {
			System.out.println("Exception Handled");
		}
		finally {
		try {
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
	}
}
