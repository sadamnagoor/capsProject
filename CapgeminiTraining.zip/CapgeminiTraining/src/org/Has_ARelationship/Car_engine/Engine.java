package org.Has_ARelationship.Car_engine;

public class Engine {
	
	String fueltype="Diesel";
		String mileage="18.4 kmpl";
		
		public void run()
		{
			System.out.println("After Starting Engine Runs");
		}
		public void stop()
		{
			System.out.println("Engine Stops");
		}

}
