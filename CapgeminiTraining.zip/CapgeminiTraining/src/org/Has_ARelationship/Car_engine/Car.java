package org.Has_ARelationship.Car_engine;

public class Car {

	String modal="Honda";
	double price=1500000;
	
	Engine en=new Engine();
	
	public void turnOn()
	{
		System.out.println("Turn on the key to start the car");
		en.run();
	}
	public void  turnOff()
	{
		System.out.println("Turn off the key to stop the car");
		en.stop();
	}
}
class Main
{
	public static void main(String[] args) {
		Car c=new Car();
		System.out.println("modal is: "+c.modal);
		System.out.println("price is: "+c.price);
		System.out.println("fueltype is: "+c.en.fueltype);
		System.out.println("mileage is: "+c.en.mileage);
		c.turnOn();
		c.turnOff();
		
	}
}
