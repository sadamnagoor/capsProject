package org.Has_ARelationship.Mobile_Battery;

public class Mobile{

	String modal="moto E4 plus";
	double price=8999;
	Battery b=new Battery();
	
	public void call()
	{
		System.out.println("make calls with the mobile");
		b.discharging();
	}
	
	public void chat()
	{
		System.out.println("catting");
		b.discharging();
	}
	public void connectToPower()
	{
		System.out.println("Connect To Power");
		b.charging();
	}
	
}
class Main
{
	public static void main(String[] args) {
		Mobile m=new Mobile();
		System.out.println("modal is: "+m.modal);
		System.out.println("price is: "+m.price);
		System.out.println("Battery Capacity is: "+m.b.capacity);
		System.out.println("Battery Type is: "+m.b.type);
		m.call();
		m.chat();
		m.connectToPower();
		
	}
}