package org.Has_ARelationship.Mobile_Battery;

public class Battery
{
	String capacity="5000mah";
	String type="non-removable";
 
	public void insert()
	{
		System.out.println("Insert into mobile");
	}
	public void charging() {
		System.out.println("mobile is charging");
	}
	public void discharging()
	{
		System.out.println("charging is going down");
	}
}
