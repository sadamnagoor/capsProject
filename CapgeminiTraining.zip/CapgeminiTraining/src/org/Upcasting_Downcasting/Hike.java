package org.Upcasting_Downcasting;

public class Hike extends Messaging {

	@Override
	public void msg() {
	System.out.println("Meaasge Using Hike");
	}
	public void old()
	{
		System.out.println("Old Versoin");
	}
	
}
