package org.Upcasting_Downcasting;

public class WhatsApp extends Messaging {
	@Override
	public void msg() {
		System.out.println("Message Using WhatsApp");
	}
	public void call() {
		System.out.println("Calling Also done");
	}
	

}
