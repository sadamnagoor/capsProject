package org.Upcasting_Downcasting;

public class Messaging {

	public void msg()
	{
		System.out.println("Message");
	}
}

