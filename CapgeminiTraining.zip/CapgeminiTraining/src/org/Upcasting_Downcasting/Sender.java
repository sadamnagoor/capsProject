package org.Upcasting_Downcasting;

public class Sender {

	public void send(Messaging ms)
	{
		ms.msg();
		WhatsApp wts=(WhatsApp)ms;
		wts.call();
	}
}
class Main
{
	public static void main(String[] args) {
		Sender s=new Sender();
		s.send(new WhatsApp());
		
		
	}
}
