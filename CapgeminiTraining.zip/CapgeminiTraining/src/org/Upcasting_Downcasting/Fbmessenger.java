package org.Upcasting_Downcasting;

public class Fbmessenger extends Messaging {
	@Override
	public void msg() {
		System.out.println("msg using fbmessenger");
	}
	public void consume()
	{
		System.out.println("Consumes More Memory");
	}

}
