package org.SuperStatement;

public class Demo1 extends Demo {

	int b=50;
	Demo1(int b)
	{
		super(20);
		System.out.println("Demo1");
		System.out.println("b="+b);
		this.b=b;
		System.out.println("this.b="+b);
	}
}
class Main
{
	public static void main(String[] args) {
		Demo1 ref=new Demo1(55);
	}
}
