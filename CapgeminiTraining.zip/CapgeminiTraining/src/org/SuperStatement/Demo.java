package org.SuperStatement;

public class Demo 
{
	int a=25;
 Demo(int a){
	System.out.println("Demo");
	System.out.println("a="+a);
	this.a=a;
	System.out.println("this.a="+a);
	}
}
