package org.Abstraction;

public class Savings implements Account {

	String accountname;
	long accountno;
	double balance;
	Savings(String accountname,long accountno,double balance)
	{
		this.accountname=accountname;
		this.accountno=accountno;
		this.balance=balance;
	}
	@Override
	public void withDraw(int amount) 
	{
		if(amount<balance)
		{
			System.out.println("amount withdrawn");
			balance=balance-amount;
		}
		else
		{
			System.out.println("Amount Insufficient");
		}
	}
	@Override
	public void deposit(int amount) {
		balance=balance+amount;
		System.out.println("Deposited");
	}
	@Override
	public void checkBalance() {
		
		System.out.println("Account Balance is: "+balance);
		
	}
	
}
