package org.Abstraction;



public class AccountManager 
{
public static Account createAccount(String name,double balance,long mobilno,char type)

{     
        if(type=='s')
        {
        	return new Savings(name, mobilno, balance);
        }
        else
        {
        	return new Loans(name, mobilno, balance);
        }
}
}
