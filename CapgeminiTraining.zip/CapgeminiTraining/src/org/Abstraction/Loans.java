package org.Abstraction;

public class Loans implements Account {
	String accountname;
	long accountno;
	double balance;
	Loans(String accountname,long accountno,double balance)
	{
		this.accountname=accountname;
		this.accountno=accountno;
		this.balance=balance;
	}
	@Override
	public void withDraw(int amount) {
		balance=balance+amount;
		System.out.println("Withdrawn Succesfully");
	}
	@Override
	public void deposit(int amount) {
		if(amount<=balance)
		{
			System.out.println("Deposited Succesfully");
			balance=balance-amount;
		}
		else
		{
			System.out.println("Deposit Balance Amount Only");
		}
	}
	@Override
	public void checkBalance() {
		
		System.out.println("Loan Amount balance is: "+balance);
		
	}

}
