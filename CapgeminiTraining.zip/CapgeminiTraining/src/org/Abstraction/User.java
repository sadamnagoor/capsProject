package org.Abstraction;

import java.util.Scanner;

public class User {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome To HDFC Bank");
		System.out.println("Enter the Account Name ");
		String name=sc.next();
		System.out.println("Enter the Amount Want To Deposite");
		double balance=sc.nextDouble();
		System.out.println("Enter the Mobile no");
		long mobileno=sc.nextLong();
		System.out.println("Enter the Account Type");
		System.out.println("Type S-savings account or other any Keywords for loan Account");
		char type=sc.next().charAt(0);
		Account ref=AccountManager.createAccount(name, balance, mobileno, type);
		System.out.println("Enter the Amount for Withdraw");
		int amount=sc.nextInt();
		ref.withDraw(amount);
		ref.checkBalance();
		System.out.println("Enter the How Much you want to deposit");
		int amnt=sc.nextInt();
		ref.deposit(amnt);
		ref.checkBalance();
		sc.close();
	}
}
