package org.Abstraction;

public interface Account
{
 void withDraw(int amount);
 void deposit(int amount);
 void checkBalance();
}
