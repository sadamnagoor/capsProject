package org.ExceptionHandling;

public class SomeException extends RuntimeException
{
   public static void main(String[] args) {
	   System.out.println("Content not found");
}
}
