package org.ExceptionHandling;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Main extends RuntimeException
{
	SomeException some;
	public void connectDB(String mail,String pass) throws SomeException
	{
		ResultSet resultSet=CustomExecption.connectToDataBase();
		
		try {
			if(resultSet.next())
			{
				
			}
			else
			{
				throw  new SomeException();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
public static void main(String[] args) {
	
}
}
