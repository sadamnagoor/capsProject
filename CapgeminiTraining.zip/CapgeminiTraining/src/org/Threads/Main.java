package org.Threads;

public class Main {
public static void main(String[] args) {
	ThreadA a=new ThreadA();
	a.start();
	ThreadA a2=new ThreadA();
	a2.start();
}
}
