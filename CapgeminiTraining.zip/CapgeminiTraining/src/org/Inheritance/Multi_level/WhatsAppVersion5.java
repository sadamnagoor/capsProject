package org.Inheritance.Multi_level;

public class WhatsAppVersion5 {
	
	public void chat()
	{
		System.out.println("chat");
	}

}
