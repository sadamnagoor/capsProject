package org.Inheritance.Multi_level;

public class WhatsAppVersion6 extends WhatsAppVersion5{

	public void call()
	{
		System.out.println("Call Using Whatsaap");
	}
}
