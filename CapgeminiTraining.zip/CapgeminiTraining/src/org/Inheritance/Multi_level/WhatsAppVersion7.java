package org.Inheritance.Multi_level;

public class WhatsAppVersion7 extends WhatsAppVersion6 {
	
	public void videoCall()
	{
		System.out.println("Video Calls Also can be Done");
	}

}
class Main
{
	public static void main(String[] args) {
		WhatsAppVersion7 ref=new WhatsAppVersion7();
		ref.chat();
		ref.call();
		ref.videoCall();
	}
}
