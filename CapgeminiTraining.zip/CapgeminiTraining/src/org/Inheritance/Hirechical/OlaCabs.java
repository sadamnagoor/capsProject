package org.Inheritance.Hirechical;

public class OlaCabs extends Maps
{

	
}
class Main
{
	public static void main(String[] args) {
		OlaCabs ola=new OlaCabs();
		ola.findRoute();
	}
}
