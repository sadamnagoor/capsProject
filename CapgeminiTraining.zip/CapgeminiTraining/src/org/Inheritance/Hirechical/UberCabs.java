package org.Inheritance.Hirechical;

public class UberCabs extends Maps{
	public static void main(String[] args) {
		
		UberCabs ub=new UberCabs();
		ub.findRoute();
	}
}
