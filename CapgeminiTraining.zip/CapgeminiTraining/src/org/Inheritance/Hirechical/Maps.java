package org.Inheritance.Hirechical;

public class Maps 
{
    public void findRoute()
    {
    	System.out.println("Find Route Using Maps");
    }
}
