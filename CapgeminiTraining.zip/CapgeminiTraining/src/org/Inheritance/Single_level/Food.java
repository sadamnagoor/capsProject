package org.Inheritance.Single_level;

public class Food {

	String type;
	double price;
	
	public void eat()
	{
		System.out.println("Eat food");
	}
}
