package org.Inheritance.Single_level;

public class Biryani extends Food {

	public void eatBiryani()
	{
		System.out.println("Eat Biryani");
	}
	
}
class Main
{
	public static void main(String[] args) {
		Biryani b=new Biryani();
		b.type="Non-Veg";
		b.price=99.99;
		System.out.println("Type of Food is: "+b.type);
		System.out.println("Price of Food is: "+b.price);
		b.eat();
		b.eatBiryani();
	}
}
