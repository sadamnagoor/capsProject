package com.dev.hotelbooking.Util;

public interface UserCredentials {

	final static String DBURL="jdbc:mysql://localhost:3306/hotel_booking";
	final static String NAME="root";
	final static String PASSWORD="root";
}
