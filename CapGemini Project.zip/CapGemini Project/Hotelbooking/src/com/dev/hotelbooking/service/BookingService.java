package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.BookingDetailsDTO;

public class BookingService {

	public static boolean booking(BookingDetailsDTO bookingDetailsDTO) {
		  boolean result=false;
		  DAO userDAO=new DAOImpl();
		  
		            result=userDAO.booking(bookingDetailsDTO);
		            
		         return result;
	}

}
