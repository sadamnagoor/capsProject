package com.dev.hotelbooking.service;

import java.util.List;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.RoomDetailsDTO;

public class ListOfRoomsService 
{
   public static List<RoomDetailsDTO> listOfRooms(RoomDetailsDTO roomDetailsDTO) 
   {
	   DAO dao=new DAOImpl();
	   List<RoomDetailsDTO> detailsDTOs =dao.listRooms(roomDetailsDTO);
	   
	   return detailsDTOs;
   }
}
