package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.HotelDTO;

public class UpdateHotelService {

	public static boolean updateHotel(HotelDTO hotelDTO) {
		boolean h = false;
		DAO dao=new DAOImpl();
		h=dao.updateHotel(hotelDTO);
		return h;
	}

}
