package com.dev.hotelbooking.service;

import java.util.List;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.HotelDTO;

public class HotelViewService {

	public static List<HotelDTO> hotelsView(HotelDTO dto)
	{
		DAO dao=new DAOImpl();
		List<HotelDTO> dto2=dao.hotelsView(dto);
		return dto2;
	}
 }
