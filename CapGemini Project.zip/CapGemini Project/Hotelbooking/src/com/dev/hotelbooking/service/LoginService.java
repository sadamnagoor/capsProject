package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.UserDTO;

public class LoginService {

	public static UserDTO userLogin(UserDTO user)
	
	{
		DAO dao=new DAOImpl();
		
		 UserDTO users=dao.userLogin(user);
		
		return users;
	}
}
