package com.dev.hotelbooking.service;

import java.util.List;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.UserDTO;

public class ListAllUsersService {

	public static List<UserDTO> list(UserDTO userDTO)
	{
		DAO dao=new DAOImpl();
		List<UserDTO> list=dao.listUsers(userDTO);
		
		return list;
	}
}
