package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.HotelDTO;

public class AddHotelService {

	public static boolean addHotel(HotelDTO hotelDTO) {
		boolean add = false;
		DAO dao=new DAOImpl();
		add=dao.addHotel(hotelDTO);
		return add;
	}

}
