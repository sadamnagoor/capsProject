package com.dev.hotelbooking.service;

import java.util.List;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.BookingDetailsDTO;

public class ListOfBookingService
{
public static List<BookingDetailsDTO> bookingsList(BookingDetailsDTO bookingDetailsDTO)
{
	DAO dao=new DAOImpl();
	List<BookingDetailsDTO> list=dao.listBookings(bookingDetailsDTO);
	return list;
}
}
