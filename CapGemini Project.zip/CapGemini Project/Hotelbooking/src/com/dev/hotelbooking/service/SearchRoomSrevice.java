package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.RoomDetailsDTO;

public class SearchRoomSrevice {

	public static RoomDetailsDTO roomDetails(String id)
	{
		DAO dao=new DAOImpl();
		RoomDetailsDTO roomDetailsDTO=dao.searchRoom(id);
		
		return roomDetailsDTO;
	}
}
