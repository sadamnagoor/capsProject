package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.UserDTO;

public class UpdateService 
{

	
	public static boolean update(UserDTO userDTO)
	
	{
		boolean result=false;
		
		DAO dao=new DAOImpl();
		
		result=dao.updateUser(userDTO);
		
		return result;
	        	
	}
}
