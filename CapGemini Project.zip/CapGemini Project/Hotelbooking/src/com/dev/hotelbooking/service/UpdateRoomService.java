package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.RoomDetailsDTO;

public class UpdateRoomService {

	public static boolean updateRoom(RoomDetailsDTO roomDetailsDTO)
	{
		DAO dao=new DAOImpl();
		boolean res=dao.updateRoom(roomDetailsDTO);
		return res;
	}
}
