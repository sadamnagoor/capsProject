package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.RoomDetailsDTO;


public class AddRoomService
{
public static boolean addRoom(RoomDetailsDTO detailsDTO)
{
	DAO dao=new DAOImpl();
	boolean add=dao.addRoom(detailsDTO);
	return add;
}
}
