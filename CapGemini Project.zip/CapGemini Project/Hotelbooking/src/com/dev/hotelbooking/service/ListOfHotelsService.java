package com.dev.hotelbooking.service;

import java.util.List;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.HotelDTO;

public class ListOfHotelsService {

	public static List<HotelDTO> listHotel(HotelDTO dto)
	{
		DAO dao=new DAOImpl();
		List<HotelDTO> hotel=dao.listHotels(dto);
		return hotel;
	}
}
