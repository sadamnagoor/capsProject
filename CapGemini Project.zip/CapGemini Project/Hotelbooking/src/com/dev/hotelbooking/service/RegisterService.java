package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.UserDTO;

public class RegisterService
{
	public   static boolean register(UserDTO userDTO)
	  {
		  boolean result=false;
		  DAO userDAO=new DAOImpl();
		  
		            result=userDAO.registerUser(userDTO);
		            
		         return result;
	  }
}
