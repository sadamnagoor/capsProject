package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.HotelDTO;

public class HotelSearchService {

	public static HotelDTO search(String id)
	  {
		 
		boolean result=false;
		
		
		DAO hotelDAO=new DAOImpl();
		  
      HotelDTO dto2=hotelDAO.searchHotel(id);
      
      return dto2;
}
}
