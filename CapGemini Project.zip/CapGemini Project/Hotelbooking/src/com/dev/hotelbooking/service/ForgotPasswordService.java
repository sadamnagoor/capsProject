package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.UserDTO;

public class ForgotPasswordService 
{
public static UserDTO forgotPass(UserDTO user)
	
	{
		DAO dao=new DAOImpl();
		
		 UserDTO users=dao.forgotPassword(user);
		
		return users;
	}
}
