package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;

public class DeleteHotelService 
{

	public static boolean deleteHotel(String id)
	{
		DAO dao=new DAOImpl();
		boolean b=dao.deleteHotel(id);
		return b;
	}
}
