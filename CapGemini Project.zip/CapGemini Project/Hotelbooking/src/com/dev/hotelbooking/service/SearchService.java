package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.HotelDTO;

public class SearchService 
{

	public static HotelDTO location(HotelDTO dto)
	{
		DAO dao=new DAOImpl();
		HotelDTO dto2=dao.serchLoc(dto);
		return dto2;
	}
}
