package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.UserDTO;

public class DeleteUserService 
{
     public static boolean  deleteUser(String name) 
     
     {
    	 DAO dao=new DAOImpl();
    	 
    	 boolean r=dao.deleteUser(name);
    	 
    	 return r;
     }
}
