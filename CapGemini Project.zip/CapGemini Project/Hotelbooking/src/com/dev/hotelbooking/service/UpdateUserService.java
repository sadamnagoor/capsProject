package com.dev.hotelbooking.service;

import com.dev.hotelbooking.dao.DAO;
import com.dev.hotelbooking.dao.DAOImpl;
import com.dev.hotelbooking.dto.UserDTO;

public class UpdateUserService 
{

	
	public static UserDTO update(UserDTO userDTO)
	
	{
		
		
		DAO dao=new DAOImpl();
		
		UserDTO user=dao.updateUser(userDTO);
		
		return user;
	        	
	}
}
