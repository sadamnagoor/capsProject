
package com.dev.hotelbooking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.dev.hotelbooking.Util.UserCredentials;
import com.dev.hotelbooking.dto.BookingDetailsDTO;
import com.dev.hotelbooking.dto.HotelDTO;
import com.dev.hotelbooking.dto.RoomDetailsDTO;
import com.dev.hotelbooking.dto.UserDTO;
import com.sun.javafx.scene.text.HitInfo;



public class DAOImpl implements DAO
{
	
	@Override
	public boolean registerUser(UserDTO userDTO) {
		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "insert into Users values(?,?,?,?,?,?,?,?)";
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1,userDTO.getUserId());
			preparedStatement.setString(2,userDTO.getPassword());
			preparedStatement.setString(3,userDTO.getRole());
			preparedStatement.setString(4,userDTO.getUserName());
			preparedStatement.setString(5,userDTO.getMobileNo());
			preparedStatement.setString(6,userDTO.getPhone());
			preparedStatement.setString(7,userDTO.getAddress() );
			preparedStatement.setString(8,userDTO.getEmail());
			
			
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("User registered succesfully");
				result=true;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
		
	}

	@Override
	public UserDTO updateUser(UserDTO userDTO) {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);
			
			String query = "Update users set user_name=?, password=?,phone=?,address =?,email=? where mobile_no=? and role=?";
			
			
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,userDTO.getUserName());
			preparedStatement.setString(2,userDTO.getPassword());
			preparedStatement.setString(3,userDTO.getPhone());
			preparedStatement.setString(4,userDTO.getAddress() );
			preparedStatement.setString(5, userDTO.getEmail());
			preparedStatement.setString(6,userDTO.getMobileNo());
			preparedStatement.setString(7,userDTO.getRole());
			
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("Updated succesfully");
				return userDTO;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		userDTO=null;
		return userDTO;
	}

	@Override
	public boolean deleteUser(String name) {
		
		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "Delete from users where user_name=?";
			
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1,name);
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("Deleted succesfully");
				return true;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return false;
	}

	@Override
	public UserDTO userLogin(UserDTO userDTO) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String dburl = "jdbc:mysql://localhost:3306/hotel_booking";
			connection = DriverManager.getConnection(dburl,"root","root");
			
			String query = "Select * from users where user_name=? and password=? and role=?";
			
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1,userDTO.getUserName());
			preparedStatement.setString(2, userDTO.getPassword());
			preparedStatement.setString(3, userDTO.getRole());
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
			
				System.out.println("Entered");
				return userDTO;
				
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
		
		userDTO=null;
		return userDTO ;
	}

	
	


	

	@Override
	public HotelDTO searchHotel(String id) 
	{
		
		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
        HotelDTO dto=new HotelDTO();		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "SELECT hotel_id,hotel_name,phone_no1,phone_no2,address,description,email,fax,avg_rate_pernight,city,rating FROM hotel WHERE hotel_id="+id;
			
			preparedStatement = connection.prepareStatement(query);
			
			//preparedStatement.setString(1,id);
			
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				dto.setHotelId(resultSet.getString(1));
				dto.setHotelName(resultSet.getString(2));
				dto.setPhoneNo1(resultSet.getString(3));
				dto.setPhoneNo2(resultSet.getString(4));
				dto.setAddress(resultSet.getString(5));
				dto.setDescription(resultSet.getString(6));
				dto.setEmail(resultSet.getString(7));
				dto.setFax(resultSet.getString(8));
				dto.setAverageRatePernight(resultSet.getDouble(9));
				dto.setCity(resultSet.getString(10));
				dto.setRating(resultSet.getString(11));
				return dto;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
		dto=null;
		return dto ;

	}


		@Override
	public boolean booking(BookingDetailsDTO bookingDetailsDTO) {
		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "insert into bookingdetails values(?,?,?,?,?,?,?)";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,bookingDetailsDTO.getRoomId());
			preparedStatement.setString(2,bookingDetailsDTO.getUserId());
			preparedStatement.setDouble(3,bookingDetailsDTO.getAmount());
			preparedStatement.setDate(4,bookingDetailsDTO.getBoookedFrom());
			preparedStatement.setDate(5,bookingDetailsDTO.getBookedTo());
			preparedStatement.setInt(6,bookingDetailsDTO.getNoOfAdults());
			preparedStatement.setInt(7,bookingDetailsDTO.getNoOfChildren());
			
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("User registered succesfully");
				result=true;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	
	}
	

	@Override
	public boolean addHotel(HotelDTO hotelDTO) {
		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);
			
			String query = "insert into hotel values(?,?,?,?,?,?,?,?,?,?,?)";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,hotelDTO.getHotelId());
			preparedStatement.setString(2,hotelDTO.getHotelName());
			preparedStatement.setString(3,hotelDTO.getCity());
			preparedStatement.setString(4,hotelDTO.getAddress());
			preparedStatement.setString(5,hotelDTO.getDescription());
			preparedStatement.setDouble(6,hotelDTO.getAverageRatePernight());
			preparedStatement.setString(7,hotelDTO.getFax() );
			preparedStatement.setString(8,hotelDTO.getPhoneNo1());
			preparedStatement.setString(9,hotelDTO.getPhoneNo2());
			preparedStatement.setString(10,hotelDTO.getRating());
			preparedStatement.setString(11,hotelDTO.getEmail());
			
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("Hotel added succesfully");
				result=true;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
		
	}

	

	@Override
	public boolean updateHotel(HotelDTO hotelDTO) {
		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			
			String query = "Update hotel set city=?,hotel_name=?,address=?,description=?,avg_rate_pernight=?,phone_no1=?,phone_no2=?,rating=?,email=?,fax=? where hotel_id=?";
			
			
			preparedStatement = connection.prepareStatement(query);
			
			
			preparedStatement.setString(1,hotelDTO.getCity());
			preparedStatement.setString(2,hotelDTO.getHotelName());
			preparedStatement.setString(3,hotelDTO.getAddress());
			preparedStatement.setString(4,hotelDTO.getDescription());
			preparedStatement.setDouble(5,hotelDTO.getAverageRatePernight());
			preparedStatement.setString(6,hotelDTO.getPhoneNo1() );
			preparedStatement.setString(7,hotelDTO.getPhoneNo2());
			preparedStatement.setString(8, hotelDTO.getRating());
			preparedStatement.setString(9,hotelDTO.getEmail());
			preparedStatement.setString(10,hotelDTO.getFax());
			preparedStatement.setString(11,hotelDTO.getHotelId());
			
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("Updated succesfully");
				result=true;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;


	}

	@Override
	public boolean deleteHotel(String id) {

		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");

			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);
			String query = "Delete from hotel where hotel_id=?";
			
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1,id);
                          int count= preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("Deleted succesfully");
				result=true;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return result;

	
	}

	@Override
	public boolean addRoom(RoomDetailsDTO roomDetailsDTO) {
		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "insert into roomdetails(hotel_id,room_no,room_type,per_night_rate,availability,photo) values(?,?,?,?,?,?)";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,roomDetailsDTO.getHotelId());
			preparedStatement.setString(2,roomDetailsDTO.getRoomNo());
			preparedStatement.setString(3,roomDetailsDTO.getRoomType());
			preparedStatement.setDouble(4,roomDetailsDTO.getPerNightRate());
			preparedStatement.setBoolean(5, roomDetailsDTO.isAvailability());
			preparedStatement.setBlob(6, roomDetailsDTO.getPhoto());
			
		
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("Uploaded  succesfully");
				result=true;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
		

	}

	@Override
	public boolean updateRoom(RoomDetailsDTO roomDetailsDTO) {
		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "Update roomdetails set room_no=?,room_type=?,per_night_rate=?,availability=?,hotel_id=?,photo=? where room_id=?";
			
			
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,roomDetailsDTO.getRoomNo());
			preparedStatement.setString(2,roomDetailsDTO.getRoomType());
			preparedStatement.setDouble(3,roomDetailsDTO.getPerNightRate());
			preparedStatement.setBoolean(4,roomDetailsDTO.isAvailability());
			preparedStatement.setString(5,roomDetailsDTO.getHotelId());
			preparedStatement.setBlob(6, roomDetailsDTO.getPhoto());
			preparedStatement.setString(7,roomDetailsDTO.getRoomId());
			
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("Updated succesfully");
				result=true;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	
	}

	@Override
	public boolean deleteRoom(String id) {
		boolean result=false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "Delete from roomdetails where room_id=?";
			
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1,id);
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("Deleted succesfully");
				result=true;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return result;
	}

	@Override
	public UserDTO forgotPassword(UserDTO dto) {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "Select password from users where user_name=? and role=?";
			
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1,dto.getUserName());
			preparedStatement.setString(2, dto.getRole());
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
			
				
				dto.setPassword(resultSet.getString("password"));
				return dto;
				
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
		dto=null;
		return dto ;
	
	}

	@Override
	public List<UserDTO> listUsers(UserDTO userDTO) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<UserDTO> list=new ArrayList<UserDTO>();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "select * from users";
			
			preparedStatement = connection.prepareStatement(query);
			resultSet =preparedStatement.executeQuery();
			
			
			while(resultSet.next())
			{
			          userDTO=new UserDTO();
			          
			         userDTO.setUserId(resultSet.getString(1));
			         userDTO.setPassword(resultSet.getString(2));
			         userDTO.setRole(resultSet.getString(3));
			         userDTO.setUserName(resultSet.getString(4));
			         userDTO.setMobileNo(resultSet.getString(5));
			         userDTO.setPhone(resultSet.getString(6));
			         userDTO.setAddress(resultSet.getString(7));
			         userDTO.setEmail(resultSet.getString(8));
			         
			          
			          list.add(userDTO);
	
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
		
		return list;
	

	}

	@Override
	public List<HotelDTO> listHotels(HotelDTO hotelDTO) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<HotelDTO> list=new ArrayList<HotelDTO>();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "Select hotel_id,hotel_name,email,description,phone_no1,phone_no2,rating,fax,avg_rate_pernight,address,city from hotel";
			
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
			
			
			while(resultSet.next())
			{
			          hotelDTO=new HotelDTO();
			        hotelDTO.setHotelId(resultSet.getString(1));
			        hotelDTO.setHotelName(resultSet.getString(2));
			        hotelDTO.setEmail(resultSet.getString(3));
			        hotelDTO.setDescription(resultSet.getString(4));
			        hotelDTO.setPhoneNo1(resultSet.getString(5));
			        hotelDTO.setPhoneNo2(resultSet.getString(6));
			        hotelDTO.setRating(resultSet.getString(7));
			        hotelDTO.setFax(resultSet.getString(8));
			        hotelDTO.setAverageRatePernight(resultSet.getDouble(9));
			        hotelDTO.setAddress(resultSet.getString(10));
			        hotelDTO.setCity(resultSet.getString(11));
			         
			         
			          
			          list.add(hotelDTO);
	
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
		
		return list;
		
	}

	@Override
	public List<RoomDetailsDTO> listRooms(RoomDetailsDTO roomDetailsDTO) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<RoomDetailsDTO> list=new ArrayList<RoomDetailsDTO>();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "Select * from roomdetails";
			
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
			
			
			while(resultSet.next())
			{
				roomDetailsDTO=new RoomDetailsDTO();
			         
				
				              roomDetailsDTO.setHotelId(resultSet.getString(1));
				              roomDetailsDTO.setRoomId(resultSet.getString(2));
				              roomDetailsDTO.setRoomNo(resultSet.getString(3));
				              roomDetailsDTO.setRoomType((resultSet.getString(4)));
				              roomDetailsDTO.setAvailability(resultSet.getBoolean(5));
				              roomDetailsDTO.setPerNightRate(resultSet.getDouble(6));
				              roomDetailsDTO.setPhoto(resultSet.getBlob(7));
				              
			         
			          list.add(roomDetailsDTO);
	
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
		
		return list;
	
	}

	@Override
	public List<BookingDetailsDTO> listBookings(BookingDetailsDTO bookingDetailsDTO) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<BookingDetailsDTO> list=new ArrayList<BookingDetailsDTO>();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "Select * from bookingdetails";
			
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
			
			
			while(resultSet.next())
			{
				bookingDetailsDTO=new BookingDetailsDTO();
			        
				           bookingDetailsDTO.setUserId(resultSet.getString(1));
				           bookingDetailsDTO.setRoomId(resultSet.getString(2));
				           bookingDetailsDTO.setBoookedFrom(resultSet.getDate(3));
				           bookingDetailsDTO.setBookedTo(resultSet.getDate(4));
				           bookingDetailsDTO.setAmount(resultSet.getDouble(5));
				           bookingDetailsDTO.setNoOfAdults(resultSet.getInt(6));
				           bookingDetailsDTO.setNoOfChildren(resultSet.getInt(7));
				           bookingDetailsDTO.setBookingId(resultSet.getString(9));
				
			          list.add(bookingDetailsDTO);
	
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
		
		return list;
	
	}

	@Override
	public UserDTO updateAdmin(UserDTO userDTO) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);
			
			String query = "Update users set user_name=?, password=?,phone=?,address =?,email=? where mobile_no=? and role=?";
			
			
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,userDTO.getUserName());
			preparedStatement.setString(2,userDTO.getPassword());
			preparedStatement.setString(3,userDTO.getPhone());
			preparedStatement.setString(4,userDTO.getAddress() );
			preparedStatement.setString(5, userDTO.getEmail());
			preparedStatement.setString(6,userDTO.getMobileNo());
			preparedStatement.setString(7,userDTO.getRole());
			
			int count = preparedStatement.executeUpdate();
			if(count>0)
			{
				System.out.println("Updated succesfully");
				return userDTO;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return userDTO;
	
	}

	@Override
	public HotelDTO serchLoc(HotelDTO dto) {
	
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet=null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);
			
			String query = "select * from hotel where city=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,dto.getCity());
			
			
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				return dto;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return dto;
		
	}

	@Override
	public RoomDetailsDTO searchRoom(String id) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet=null;
		RoomDetailsDTO roomDetailsDTO=new RoomDetailsDTO();
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "select hotel_id,room_no,room_type,per_night_rate,availability,photo from roomdetails where room_id=?";
			
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1, id);
			
			 resultSet=preparedStatement.executeQuery();
			
			
			if(resultSet.next())
			{
				roomDetailsDTO.setRoomId(id);
				roomDetailsDTO.setHotelId(resultSet.getString(1));
				roomDetailsDTO.setRoomNo(resultSet.getString(2));
				roomDetailsDTO.setRoomType(resultSet.getString(3));
				roomDetailsDTO.setPerNightRate(resultSet.getDouble(4));
				roomDetailsDTO.setAvailability(resultSet.getBoolean(5));
				roomDetailsDTO.setPhoto(resultSet.getBlob(6));
				
				return roomDetailsDTO;
			}
			else
			{
				System.out.println("Something went wrong");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		roomDetailsDTO=null;
		return roomDetailsDTO;
	
	}

	@Override
	public List<HotelDTO> hotelsView(HotelDTO hotelDTO) {
	
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<HotelDTO> list=new ArrayList<HotelDTO>();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(UserCredentials.DBURL, UserCredentials.NAME, UserCredentials.PASSWORD);

			String query = "Select hotel_id,hotel_name,email,description,phone_no1,phone_no2,rating,fax,avg_rate_pernight,address,city from hotel";
			
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
			
			
			while(resultSet.next())
			{
			          hotelDTO=new HotelDTO();
			        hotelDTO.setHotelId(resultSet.getString(1));
			        hotelDTO.setHotelName(resultSet.getString(2));
			        hotelDTO.setEmail(resultSet.getString(3));
			        hotelDTO.setDescription(resultSet.getString(4));
			        hotelDTO.setPhoneNo1(resultSet.getString(5));
			        hotelDTO.setPhoneNo2(resultSet.getString(6));
			        hotelDTO.setRating(resultSet.getString(7));
			        hotelDTO.setFax(resultSet.getString(8));
			        hotelDTO.setAverageRatePernight(resultSet.getDouble(9));
			        hotelDTO.setAddress(resultSet.getString(10));
			        hotelDTO.setCity(resultSet.getString(11));
			         
			         
			          
			          list.add(hotelDTO);
	
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
		
		return list;
		

	}

	

}
