package com.dev.hotelbooking.dao;

import com.dev.hotelbooking.dto.BookingDetailsDTO;
import com.dev.hotelbooking.dto.HotelDTO;
import com.dev.hotelbooking.dto.RoomDetailsDTO;
import com.dev.hotelbooking.dto.UserDTO;

public interface DAO
{
	boolean registerUser(UserDTO userDTO);
	boolean updateUser(UserDTO userDTO);
	boolean deleteUser(String name);
	UserDTO userLogin(UserDTO userDTO);
	boolean searchHotel(String id);
    void listOfHotel(HotelDTO hotelDTO);
    boolean booking(BookingDetailsDTO bookingDetailsDTO);
    boolean addHotel(HotelDTO hotelDTO);
	boolean updateHotel(HotelDTO hotelDTO);
	boolean deleteHotel(String id);
	boolean addRoom(RoomDetailsDTO roomDetailsDTO);
    boolean updateRoom(RoomDetailsDTO roomDetailsDTO);
    boolean deleteRoom(String id);
    void roomDetails();
}
