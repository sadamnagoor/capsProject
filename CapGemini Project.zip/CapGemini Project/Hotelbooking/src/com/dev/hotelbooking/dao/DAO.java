package com.dev.hotelbooking.dao;

import java.util.List;

import com.dev.hotelbooking.dto.BookingDetailsDTO;
import com.dev.hotelbooking.dto.HotelDTO;
import com.dev.hotelbooking.dto.RoomDetailsDTO;
import com.dev.hotelbooking.dto.UserDTO;

public interface DAO
{
	boolean registerUser(UserDTO userDTO);
	UserDTO updateUser(UserDTO userDTO);
	UserDTO updateAdmin(UserDTO userDTO);
	boolean deleteUser(String name);
	UserDTO userLogin(UserDTO userDTO);
	HotelDTO searchHotel(String id);
    boolean booking(BookingDetailsDTO bookingDetailsDTO);
    boolean addHotel(HotelDTO hotelDTO);
	boolean updateHotel(HotelDTO hotelDTO);
	boolean deleteHotel(String id);
	boolean addRoom(RoomDetailsDTO roomDetailsDTO);
    boolean updateRoom(RoomDetailsDTO roomDetailsDTO);
    RoomDetailsDTO searchRoom(String id);
    boolean deleteRoom(String id);
    UserDTO forgotPassword(UserDTO dto);
    List<UserDTO> listUsers(UserDTO userDTO);
    List<HotelDTO> listHotels(HotelDTO hotelDTO);
    List<RoomDetailsDTO> listRooms(RoomDetailsDTO roomDetailsDTO);
    List<BookingDetailsDTO> listBookings(BookingDetailsDTO bookingDetailsDTO);
    HotelDTO serchLoc(HotelDTO dto);
    List<HotelDTO> hotelsView(HotelDTO hotelDTO);
    
}
