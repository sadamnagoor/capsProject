package com.dev.hotelbooking.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.UserDTO;
import com.dev.hotelbooking.service.DeleteUserService;

@WebServlet("/delete")
public class DeleteUserController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		
		String username=req.getParameter("name");
		
		
		boolean result=DeleteUserService.deleteUser(username);
		
		if(result)
		{
			System.out.println("Deleted");
			 //resp.sendRedirect("");
		}
		else
		{
			System.out.println("Somthing went wrong");
		}
	}
}
