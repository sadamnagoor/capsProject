package com.dev.hotelbooking.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.UserDTO;
import com.dev.hotelbooking.service.UpdateService;

@WebServlet("/update")
public class UpdateController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String mobileNo=req.getParameter("mobile");
				
		String name=req.getParameter("name");
		
		String password=req.getParameter("password");
		
		String phone=req.getParameter("phone");
		
		String email=req.getParameter("email");
		
		String address=req.getParameter("address");
		
		
		
		
		
		UserDTO userDTO=new UserDTO();
		
		userDTO.setMobileNo(mobileNo);
		userDTO.setUserName(name);
		userDTO.setEmail(email);
		userDTO.setAddress(address);
		userDTO.setPassword(password);
		userDTO.setPhone(phone);
		
		boolean b=UpdateService.update(userDTO);
		if(b)
		{
			System.out.println("Success");
		}
		else
		{
			System.out.println("failed");
		}
		
		
		
		
	}
}
