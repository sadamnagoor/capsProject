package com.dev.hotelbooking.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import com.dev.hotelbooking.dto.RoomDetailsDTO;
import com.dev.hotelbooking.service.UpdateRoomService;

@WebServlet("/updateroom")
@MultipartConfig
public class UpdateRoomController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		
	String roomId=req.getParameter("Roomid");
	String roomNo=req.getParameter("Roomno");
	String roomType=req.getParameter("Roomtype");
    double price=Double.parseDouble(req.getParameter("pernightrate"));
	boolean available=Boolean.parseBoolean(req.getParameter("availability"));
	String hotelid=req.getParameter("hotelid");
	
    
   
    Part filePart=req.getPart("file");
	String fileName=filePart.getSubmittedFileName();
	
	String str= new Date().getTime() + ".jpg";
	
	InputStream filStream=filePart.getInputStream();
	
      byte[] buffer=null;
      Blob blob=null;
      String fName="D:\\images\\"+fileName+str;
      
      if(fileName.length()!=0)
      {
    	  buffer=new byte[filStream.available()];
    	  filStream.read(buffer);
    	  OutputStream outputStream=new FileOutputStream(fName);
    	  outputStream.write(buffer);
    	  outputStream.close();
    	  filStream.close();
    	  try {
			blob=new SerialBlob(buffer);
		} catch (SerialException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	  System.out.println("Uploaded");
    	 }
	
	RoomDetailsDTO detailsDTO= new RoomDetailsDTO();
	
	detailsDTO.setRoomId(roomId);
	detailsDTO.setRoomNo(roomNo);
	detailsDTO.setRoomType(roomType);
	detailsDTO.setPerNightRate(price);
	detailsDTO.setAvailability(available);
	detailsDTO.setPhoto(blob);
	detailsDTO.setHotelId(hotelid);
	
  
    
    boolean rs=UpdateRoomService.updateRoom(detailsDTO);
    
		if(rs)
		{
             resp.sendRedirect("./AdminHomePage.jsp");		
		}else
		{
			System.out.println("UpdateRoom.jsp");
		}
	}
}
