package com.dev.hotelbooking.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dev.hotelbooking.dto.UserDTO;
import com.dev.hotelbooking.service.LoginService;

@WebServlet("/login")
public class LoginController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		   
		         resp.setContentType("text/html");
		         
		         
		           String name=req.getParameter("name");
		           String password=req.getParameter("password");
		           
		           UserDTO userDTO=new UserDTO();
		           userDTO.setUserName(name);
		           userDTO.setPassword(password);
		          
		           
		           
		           UserDTO result=LoginService.userLogin(userDTO);
		           HttpSession httpSession;
		           if(result !=null)
		           {
		        	   String role=userDTO.getRole();
		        	   if(role!=null)
		        	   if(role.equals("admin"))
		        	   {
		        		   httpSession =req.getSession();
				        	resp.sendRedirect("./homepage.html");
		        	   }
		        	
		               else if(role.equals("employee"))
		               {
		            	   httpSession =req.getSession();
		            	   resp.sendRedirect("./Login.html");
		            	   System.out.println("Successful");
		               }
		               else if(role.equals("user"))
		               {
		            	   httpSession =req.getSession();
		            	   resp.sendRedirect("./Login.html");
		               }
		               else
		               {
		            	   System.out.println("Somthing went wrong");
		            	   resp.sendRedirect("./Login.html");
		               }
		           
		 
		           }
	}
	}

