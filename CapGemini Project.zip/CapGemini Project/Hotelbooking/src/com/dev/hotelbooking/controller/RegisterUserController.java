package com.dev.hotelbooking.controller;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.UserDTO;
import com.dev.hotelbooking.service.RegisterUserService;

@WebServlet("/register")
public class RegisterUserController extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		  resp.setContentType("text/html");
		  
		              String email=req.getParameter("email");
		              
		              String password=req.getParameter("password");
		              
		              String userName=req.getParameter("username");
		              
		              String mobileNo=req.getParameter("mobilenumber");
		              
		              String address=req.getParameter("address");
		              
		              String phone=req.getParameter("phone");
		              
		              String role=req.getParameter("role");
		              
		              
		           
		              
		            		  
		              UserDTO userDTO=new UserDTO();
		              
		              userDTO.setEmail(email);
		              userDTO.setPassword(password);
		              userDTO.setUserName(userName);
		              userDTO.setMobileNo(mobileNo);
		              userDTO.setAddress(address);
		              userDTO.setPhone(phone);
		              userDTO.setRole(role);
		             
		              
		             
		             
		             
		             boolean result=RegisterUserService.register(userDTO);
		             
		             if(result)
		             {
		            	 
		            	 resp.sendRedirect("Login.html");
		            	 
		             }else
		             {
		            	 
		            	 resp.sendRedirect("register.html");
		             }
	}
}
