package com.dev.hotelbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.dev.hotelbooking.dto.UserDTO;
import com.dev.hotelbooking.service.ForgotPasswordService;

@WebServlet("/forgot")
public class ForgotPasswordController extends HttpServlet
{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		   resp.setContentType("text/html");
	         
	         
           String name=req.getParameter("name");
           String role=req.getParameter("role");
           
           UserDTO userDTO=new UserDTO();
            
           userDTO.setUserName(name);
           userDTO.setRole(role);
          
           PrintWriter out=resp.getWriter();
           
           UserDTO userDTO2=ForgotPasswordService.forgotPass(userDTO);
          
           if(userDTO2 !=null)
           {
        	  
        	   
        	   if(userDTO2.getRole()!=null)
        	   {
        		  
        	   if(userDTO2.getRole().equals("admin"))
        	   {
        		  
		        	out.print("<h1>"+"Your Password is: "+userDTO2.getPassword()+"</h1>");
        	   }
        	
               else if(userDTO2.getRole().equals("employee"))
               {
            	   out.print("<h1>"+"Your Password is: "+userDTO2.getPassword()+"</h1>");
            	
            	  
               }
               else if(userDTO2.getRole().equals("user"))
               {
            	   out.print("<h1>"+"Your Password is: "+userDTO2.getPassword()+"</h1>");
            	  
               }
        	   }
           }
               else
               {
            	   
            	   resp.sendRedirect("./ForgotPassword.html");
               }
           
 
         


	}
}
