package com.dev.hotelbooking.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.HotelDTO;
import com.dev.hotelbooking.service.SearchService;

@WebServlet("/searchloc")
public class SearchController extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		
		String loc=req.getParameter("location");
		
		HotelDTO dto=new HotelDTO();
		dto.setCity(loc);
		HotelDTO dto2=SearchService.location(dto);
		
		if(dto2!=null)
		{
			if(dto2.getCity().equals("Bangalore"))
			{
				resp.sendRedirect("./bangalorehotel");
				
			}else if(dto2.getCity().equals("goa"))
			{
				resp.sendRedirect("./goahotel");
			}
			else if(dto2.getCity().equals("Mumbai"))
			{
				resp.sendRedirect("./mumbaihotel");
			}
		}
		
	}
}
