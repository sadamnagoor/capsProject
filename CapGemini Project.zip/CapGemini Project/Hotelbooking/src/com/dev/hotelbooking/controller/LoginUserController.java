package com.dev.hotelbooking.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dev.hotelbooking.dto.UserDTO;
import com.dev.hotelbooking.service.LoginUserService;

@WebServlet("/login")
public class LoginUserController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		   
		         resp.setContentType("text/html");
		         
		         
		           String name=req.getParameter("name");
		           String password=req.getParameter("password");
		           String role=req.getParameter("role");
		           
		           UserDTO userDTO=new UserDTO();
		           userDTO.setUserName(name);
		           userDTO.setPassword(password);
		           userDTO.setRole(role);
		          
		           
		           
		           UserDTO userDTO2=LoginUserService.userLogin(userDTO);
		           HttpSession httpSession;
		           if(userDTO2 !=null)
		           {
		        	  
		        	   
		        	   if(userDTO.getRole()!=null)
		        	   {
		        		  
		        	   if(userDTO.getRole().equals("admin"))
		        	   {
		        		 
		        		   httpSession =req.getSession();
		        		  httpSession.setAttribute("user", userDTO2);
				        	resp.sendRedirect("./AdminHomePage.jsp");
				        	 
		        	   }
		        	
		               else if(userDTO.getRole().equals("employee"))
		               {
		            	   httpSession =req.getSession();
		            	   httpSession.setAttribute("user", userDTO2);
		            	   resp.sendRedirect("./UserHomepage.jsp");
		            	   
		               }
		               else if(userDTO.getRole().equals("user"))
		               {
		            	  httpSession =req.getSession();
		            	  httpSession.setAttribute("user", userDTO2);
		            	  resp.sendRedirect("./UserHomepage.jsp");
		            	   
		               }
		        	   }
		           }
		               else
		               {
		            	   
		            	   resp.sendRedirect("./Login.html");
		               }
		           
		 
		           
	
	}
}

