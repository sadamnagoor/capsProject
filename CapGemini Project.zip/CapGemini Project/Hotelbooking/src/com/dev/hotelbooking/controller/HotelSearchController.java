package com.dev.hotelbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.HotelDTO;
import com.dev.hotelbooking.service.HotelSearchService;

@WebServlet("/search")
public class HotelSearchController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
     resp.setContentType("text/html");
		
		String id=req.getParameter("hotelId");
		
		HotelDTO res=HotelSearchService.search(id);
		PrintWriter printWriter=resp.getWriter();
		
		if(res!=null)
		{ 
			System.out.println("Enterded");
			 printWriter.print("<h1>"+"Hotel Details are: "+"</h1>"+"<br>");
			 printWriter.print("<h3>"+"Hotel Id is: "+res.getHotelId()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel Name is: "+res.getHotelName()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel Rating is: "+res.getRating()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel city is : "+res.getCity()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel Email is : "+res.getEmail()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel Phone no is: "+res.getPhoneNo1()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel alternate mobile is:"+res.getPhoneNo2()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel Adress is :"+res.getAddress()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel Average per night is: "+res.getAverageRatePernight()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel Description is: "+res.getDescription()+"</h3>"+"<br>");
			 printWriter.print("<h3>"+"Hotel fax is : "+res.getFax()+"</h3>"+"<br>");
			 
			 printWriter.print("<h3>"+"--------------------------"+"</h3>");
		
		}else
		{
			
		}
		

		
		
		

	}
}
