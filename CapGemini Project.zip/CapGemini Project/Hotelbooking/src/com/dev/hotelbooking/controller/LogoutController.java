package com.dev.hotelbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/adminlogout")
public class LogoutController  extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();

		HttpSession session=req.getSession();
		if(session!=null)
		{
			session.invalidate();
			Cookie[] c=req.getCookies();
			for(Cookie cookie: c)
			{
				if(cookie.getName().equals("JSESSIONID"))
				{
					cookie.setMaxAge(0);
					resp.addCookie(cookie);
				}
			}
			resp.sendRedirect("./Login.html");
		}
	}
}
