package com.dev.hotelbooking.controller;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.HotelDTO;
import com.dev.hotelbooking.service.UpdateHotelService;

@WebServlet("/updatehotel")
public class UpdateHotelController extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		
		String hotelId = req.getParameter("hotelId");
		String city = req.getParameter("city");
		String hotelName = req.getParameter("hotelName");
		String address = req.getParameter("address");
		String description = req.getParameter("description");
		double averageRatePernight = Double.parseDouble(req.getParameter("averageRatePernight")); 
		String phoneNo1 = req.getParameter("phoneNo1");
		String phoneNo2 = req.getParameter("phoneNo2");
		String rating = req.getParameter("rating");
		String email = req.getParameter("email");
		String fax = req.getParameter("fax");
		 
		

		HotelDTO hotelDTO = new HotelDTO();

		hotelDTO.setHotelId(hotelId);
		hotelDTO.setCity(city);
		hotelDTO.setHotelName(hotelName);
		hotelDTO.setAddress(address);
		hotelDTO.setDescription(description);
		hotelDTO.setAverageRatePernight(averageRatePernight);
		hotelDTO.setPhoneNo1(phoneNo1);
		hotelDTO.setPhoneNo2(phoneNo2);
		hotelDTO.setRating(rating);
		hotelDTO.setEmail(email);
		hotelDTO.setFax(fax);
		

		boolean h = UpdateHotelService.updateHotel(hotelDTO);
		if(h)
		{
			resp.sendRedirect("./AdminHomePage.jsp");
		}
		else
		{
			resp.sendRedirect("./UpdateHotel.jsp");
		}

	}

}
