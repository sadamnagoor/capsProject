package com.dev.hotelbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.UserDTO;
import com.dev.hotelbooking.service.ListAllUsersService;

@WebServlet("/getusers")
public class ListAllUsersController extends HttpServlet
{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		UserDTO userDTO=new UserDTO();
		resp.setContentType("text/html");
		List<UserDTO> list=ListAllUsersService.list(userDTO);
		
		PrintWriter printWriter=resp.getWriter();
		if(list!=null)
		{
			System.out.println("Entered");
			
				
				for(int i=0;i<list.size();i++)
				{
					userDTO=list.get(i);
					if(userDTO.getRole().equals("employee"))
					{
						
					printWriter.print("<h1>"+"Employee details are :"+"<br>");
					
						printWriter.print("<h3>"+"Employee name is :"+userDTO.getUserName());
						printWriter.print("<h3>"+"Employee id is :"+userDTO.getUserId());
						printWriter.print("<h3>"+"Employee  Email is :"+userDTO.getEmail());
						printWriter.print("<h3>"+"Employee  MobileNo is :"+userDTO.getMobileNo());
						printWriter.print("<h3>"+"Employee phone is :"+userDTO.getPhone());
						printWriter.print("<h3>"+"Employee Address is :"+userDTO.getAddress());
						 
						printWriter.print("<h3>"+"--------------------------"+"</h3>");
					
					
					
					
					}else if(userDTO.getRole().equals("user"))
					{
						
							
						
						printWriter.print("<h1>"+"User details are :");
						printWriter.print("<h3>"+"User name is :"+userDTO.getUserName());
						printWriter.print("<h3>"+"User id is :"+userDTO.getUserId());
						printWriter.print("<h3>"+"User  Email is :"+userDTO.getEmail());
						printWriter.print("<h3>"+"User  MobileNo is :"+userDTO.getMobileNo());
						printWriter.print("<h3>"+"User phone is :"+userDTO.getPhone());
						printWriter.print("<h3>"+"User Address is :"+userDTO.getAddress());
						
						printWriter.print("<h3>"+"--------------------------"+"</h3>");
					}
					
				}
		}
		else
		{
			resp.sendRedirect("./AdminHomePage.jsp");
		}
		
		
	}
}
