package com.dev.hotelbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.RoomDetailsDTO;
import com.dev.hotelbooking.service.ListOfRoomsService;

@WebServlet("/roomlist")
public class ListOfRoomsController extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		
		RoomDetailsDTO roomDetailsDTO=new RoomDetailsDTO();
		
		List<RoomDetailsDTO> list=ListOfRoomsService.listOfRooms(roomDetailsDTO);
		
		PrintWriter printWriter=resp.getWriter();
		if(list!=null)
		{
			for (RoomDetailsDTO roomDetailsDTO2 : list) {
				
				 printWriter.print("<h1>" + "Room details are: " + "</h1>");
	        			 
	        	printWriter.print("<h3>" + "Room id is: " +roomDetailsDTO2.getRoomId() + "</h3>");
	        			  
	        	 printWriter.print("<h3>" +"Room No is: " + roomDetailsDTO2.getRoomNo() + "</h3>");
	        			  
	        	 printWriter.print("<h3>" + "Room Type is: " + roomDetailsDTO2.getRoomType() +"</h3>");
	        			  
	        	   printWriter.print("<h3>" + "Hotel Id is: " + roomDetailsDTO2.getHotelId() + "</h3>");
	        			 
	        	   printWriter.print("<h3>" + "Price Per Night is: " + roomDetailsDTO2.getPerNightRate() + "</h3>");
	        			 
	        	   printWriter.print("<h3>" +   "Room images:</h3> <img src='d:\\nagoornew.jpg'></img>");
	        	   
	        	   printWriter.print("<h3> Room Availability :"+roomDetailsDTO2.isAvailability()+"</h3>");
	        			
			}
			
			
		}else
		{
			printWriter.print("<h1>"+"No Data Found"+"</h1>");
		}
	}
	
}
