package com.dev.hotelbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.HotelDTO;
import com.dev.hotelbooking.service.ListOfHotelsService;

@WebServlet("/hotellist")
public class ListOfHotelsController extends HttpServlet{

	 @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		 resp.setContentType("text/html");
		 
		 HotelDTO dto=new HotelDTO();
		 
		 List<HotelDTO> list=ListOfHotelsService.listHotel(dto);
		 
			PrintWriter printWriter=resp.getWriter();
		 
		 if(list!=null)
		 {
			 for (HotelDTO hotelDTO : list) {
				 
				 printWriter.print("<h1>"+"Hotel Details are: "+"</h1>");
				 printWriter.print("<h3>"+"Hotel Id is: "+hotelDTO.getHotelId()+"</h3>");
				 printWriter.print("<h3>"+"Hotel Name is: "+hotelDTO.getHotelName()+"</h3>");
				 printWriter.print("<h3>"+"Hotel Rating is: "+hotelDTO.getRating()+"</h3>");
				 printWriter.print("<h3>"+"Hotel city is : "+hotelDTO.getCity()+"</h3>");
				 printWriter.print("<h3>"+"Hotel Email is : "+hotelDTO.getEmail()+"</h3>");
				 printWriter.print("<h3>"+"Hotel Phone no is: "+hotelDTO.getPhoneNo1()+"</h3>");
				 printWriter.print("<h3>"+"Hotel alternate mobile is:"+hotelDTO.getPhoneNo2()+"</h3>");
				 printWriter.print("<h3>"+"Hotel Adress is :"+hotelDTO.getAddress()+"</h3>");
				 printWriter.print("<h3>"+"Hotel Average per night is: "+hotelDTO.getAverageRatePernight()+"</h3>");
				 printWriter.print("<h3>"+"Hotel Description is: "+hotelDTO.getDescription()+"</h3>");
				 printWriter.print("<h3>"+"Hotel fax is : "+hotelDTO.getFax()+"</h3>");
				 
				 printWriter.print("<h3>"+"--------------------------"+"</h3>");
			}
		 }
		 else
		 {
			 printWriter.print("<h1>"+"No hotels found"+"</h1>");
		 }
		 
		 
	}
}
