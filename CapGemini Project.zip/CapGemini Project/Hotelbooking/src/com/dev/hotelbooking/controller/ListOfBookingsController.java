package com.dev.hotelbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.BookingDetailsDTO;
import com.dev.hotelbooking.service.ListOfBookingService;

@WebServlet("/bookinglist")
public class ListOfBookingsController extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		BookingDetailsDTO dto=new BookingDetailsDTO();
		
		List<BookingDetailsDTO> list=ListOfBookingService.bookingsList(dto);
		
		PrintWriter printWriter=resp.getWriter();
		if(list!=null)
		{
			for (BookingDetailsDTO bookingDetailsDTO : list) {
			
				printWriter.print("<h1>"+"Booking details are :"+"</h1>");
				printWriter.print("<h3>"+bookingDetailsDTO.getBookingId()+"</h3>");
				printWriter.print("<h3>"+bookingDetailsDTO.getBoookedFrom()+"</h3>");
				printWriter.print("<h3>"+bookingDetailsDTO.getBookedTo()+"</h3>");
				printWriter.print("<h3>"+bookingDetailsDTO.getAmount()+"</h3>");
				printWriter.print("<h3>"+bookingDetailsDTO.getNoOfAdults()+"</h3>");
				printWriter.print("<h3>"+bookingDetailsDTO.getNoOfChildren()+"</h3>");
				printWriter.print("<h3>"+bookingDetailsDTO.getRoomId()+"</h3>");
				printWriter.print("<h3>"+bookingDetailsDTO.getUserId()+"</h3>");
					
			}
			
		}else
		{
			System.out.println("no data");
		}
	}

}
