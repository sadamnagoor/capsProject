package com.dev.hotelbooking.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.hotelbooking.dto.RoomDetailsDTO;
import com.dev.hotelbooking.service.SearchRoomSrevice;

@WebServlet("/searchroom")
public class SearchRoomController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
           
		resp.setContentType("text/html");

		String roomID = req.getParameter("roomid");
          
		RoomDetailsDTO roomDetailsDTO = SearchRoomSrevice.roomDetails(roomID);
		/*
		 * File file=new File("E:\\image1.png"); FileOutputStream fos=new
		 * FileOutputStream(file); byte[] by=null; Blob b=roomDetailsDTO.getPhoto(); try
		 * { by=b.getBytes(1, (int)b.length()); fos.write(by);
		 * 
		 * } catch (SQLException e) { e.printStackTrace(); }
		 * 
		 * fos.close();
		 */
		
		
//		printWriter.print("<img src='E:\\image1.png' alt='image not found'></img>");
		
		  RequestDispatcher dispatcher=req.getRequestDispatcher("./image.jsp");
		  req.setAttribute("room",roomDetailsDTO ); 
		  dispatcher.forward(req, resp);
		 
		
		

	}
}
